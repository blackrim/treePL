#include <adolc/adolc.h>

int main(int, char **)
{
        double x = 3, y = 4;

        fmax(x, y);
        fmin(x, y);

        return 0;
}
